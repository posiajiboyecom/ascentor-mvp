import { createClient } from '@/lib/supabase/server';
import { redirect } from 'next/navigation';

export default async function DashboardPage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/login');

  // Load profile
  const { data: profile } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', user.id)
    .single();

  // Load goal
  const { data: goal } = await supabase
    .from('user_goals')
    .select('*')
    .eq('user_id', user.id)
    .order('created_at', { ascending: false })
    .limit(1)
    .single();

  // Count sessions this week
  const weekAgo = new Date(Date.now() - 7 * 86400000).toISOString();
  const { count: sessionsThisWeek } = await supabase
    .from('coaching_sessions')
    .select('*', { count: 'exact', head: true })
    .eq('user_id', user.id)
    .gte('created_at', weekAgo);

  return (
    <div className="min-h-screen bg-gray-950 text-white p-8">
      <div className="max-w-2xl mx-auto">
        <h1 className="text-3xl font-bold mb-2">
          Welcome, {profile?.full_name || 'there'} 👋
        </h1>
        <p className="text-gray-400 mb-8">
          {profile?.current_role} → {profile?.goal_role}
        </p>

        {/* Stats */}
        <div className="grid grid-cols-2 gap-4 mb-8">
          <div className="bg-gray-900 border border-gray-800 rounded-xl p-5">
            <p className="text-gray-500 text-sm">Sessions This Week</p>
            <p className="text-3xl font-bold text-amber-500">{sessionsThisWeek || 0}</p>
          </div>
          <div className="bg-gray-900 border border-gray-800 rounded-xl p-5">
            <p className="text-gray-500 text-sm">Goal Progress</p>
            <p className="text-3xl font-bold text-teal-400">{goal?.progress || 0}%</p>
          </div>
        </div>

        {/* Goal */}
        {goal && (
          <div className="bg-gray-900 border border-gray-800 rounded-xl p-5 mb-8">
            <p className="text-gray-500 text-sm mb-1">90-Day Goal</p>
            <p className="text-lg font-medium">{goal.goal_text}</p>
          </div>
        )}

        {/* Link to coaching */}
        <a href="/coach"
          className="block w-full p-4 bg-amber-500 text-black font-semibold rounded-xl
                     text-center hover:bg-amber-600 transition text-lg">
          💬 Start AI Coaching Session
        </a>
      </div>
    </div>
  );
}