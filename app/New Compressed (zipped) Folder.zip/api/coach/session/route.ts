import { NextResponse } from 'next/server';

export async function POST(request: Request) {
  // 1. Read the user input
  const body = await request.json();
  const userMessage = body.userInput || body.message || "No message";

  // 2. Fake "Thinking" delay (makes it feel real)
  await new Promise(resolve => setTimeout(resolve, 1000));

  // 3. Return a fake response
  return NextResponse.json({
    response: "This is a mock response because the API is out of credits.",
    full_response: {
      reflection: "I notice you are testing the system.",
      question: "Since we are in test mode, what feature would you like to build next?",
      action: "Add $5 to Anthropic Console to enable real AI."
    }
  });
}