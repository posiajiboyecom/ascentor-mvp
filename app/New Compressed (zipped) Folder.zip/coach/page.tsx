'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function CoachPage() {
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [messages, setMessages] = useState<{role: 'user' | 'ai', content: string}[]>([
    { role: 'ai', content: "Hello! I'm your Ascentor Coach. What's on your mind?" }
  ]);
  const router = useRouter();

  const handleSend = async () => {
    if (!input.trim()) return;

    // 1. Add User Message to UI immediately
    const userMessage = input;
    setMessages(prev => [...prev, { role: 'user', content: userMessage }]);
    setInput('');
    setIsLoading(true);

    try {
      // 2. Send to YOUR existing API
      const response = await fetch('/api/coach/session', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          message: userMessage,
          // We can send history too if your API supports it
          history: messages 
        }),
      });

      if (!response.ok) {
        throw new Error(`API Error: ${response.statusText}`);
      }

      const data = await response.json();

      // 3. Add AI Response to UI
      // Note: Adjust 'data.response' if your API returns a different field name (e.g., data.message)
      setMessages(prev => [...prev, { role: 'ai', content: data.response || data.message || "I heard you, but I didn't get a text response." }]);

    } catch (error) {
      console.error(error);
      setMessages(prev => [...prev, { role: 'ai', content: "⚠️ Sorry, I'm having trouble connecting to the server." }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-950 flex flex-col text-white">
      {/* ── HEADER ── */}
      <header className="border-b border-gray-800 p-4 flex justify-between items-center bg-gray-900">
        <h1 className="text-xl font-bold">Ascentor <span className="text-amber-500">Coach</span></h1>
        <button onClick={() => router.push('/dashboard')} className="text-gray-400 hover:text-white text-sm">
          Exit Session
        </button>
      </header>

      {/* ── CHAT AREA ── */}
      <main className="flex-1 overflow-y-auto p-4 space-y-4 max-w-3xl mx-auto w-full">
        {messages.map((msg, i) => (
          <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-[80%] p-4 rounded-xl ${
              msg.role === 'user' 
                ? 'bg-amber-500 text-black rounded-tr-none' 
                : 'bg-gray-800 text-gray-100 rounded-tl-none border border-gray-700'
            }`}>
              {msg.content}
            </div>
          </div>
        ))}
        {isLoading && (
          <div className="flex justify-start">
            <div className="bg-gray-800 text-gray-400 p-4 rounded-xl rounded-tl-none animate-pulse">
              Thinking...
            </div>
          </div>
        )}
      </main>

      {/* ── INPUT AREA ── */}
      <div className="p-4 bg-gray-900 border-t border-gray-800">
        <div className="max-w-3xl mx-auto flex gap-2">
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            disabled={isLoading}
            placeholder="Type your challenge here..."
            className="flex-1 bg-gray-950 border border-gray-700 text-white rounded-lg p-4 outline-none focus:border-amber-500 disabled:opacity-50"
          />
          <button 
            onClick={handleSend}
            disabled={isLoading || !input.trim()}
            className="bg-amber-500 hover:bg-amber-600 text-black font-bold py-2 px-6 rounded-lg disabled:opacity-50 transition"
          >
            {isLoading ? '...' : 'Send'}
          </button>
        </div>
      </div>
    </div>
  );
}